import { useEffect, useState } from 'react';
import axios from 'axios';
import IOCList from './components/IOCList';
import ForecastChart from './components/ForecastChart';
import WorldMap from './components/WorldMap';
import ReportPanel from './components/ReportPanel';
import Login from './components/Login';

function App() {
  const [iocs, setIocs] = useState<any[]>([]);
  const [forecast, setForecast] = useState<any[]>([]);
  const [token, setToken] = useState(localStorage.getItem('token') || '');

  useEffect(() => {
    if (!token) return;
    axios.get('http://localhost:8000/iocs?limit=50', { headers: { Authorization: `Bearer ${token}` } })
      .then(res => setIocs(res.data.results)).catch(()=>{});
    axios.get('http://localhost:8000/forecast?days=14', { headers: { Authorization: `Bearer ${token}` } })
      .then(res => setForecast(res.data.forecast || [])).catch(()=>{});
  }, [token]);

  const handleLogin = (tok: string) => { setToken(tok); localStorage.setItem('token', tok); }

  if (!token) return <Login onLogin={handleLogin} />;

  return (
    <div className='min-h-screen bg-gray-100 p-4'>
      <div className='flex justify-between items-center mb-4'>
        <h1 className='text-3xl font-bold'>Threatwatch Dashboard</h1>
        <button onClick={() => { setToken(''); localStorage.removeItem('token'); }} className='px-3 py-1 bg-red-600 text-white rounded'>Logout</button>
      </div>
      <div className='grid grid-cols-1 lg:grid-cols-2 gap-6'>
        <div className='bg-white p-4 rounded-2xl shadow'><IOCList iocs={iocs} /></div>
        <div className='bg-white p-4 rounded-2xl shadow'><ForecastChart forecast={forecast} /></div>
        <div className='col-span-1 lg:col-span-2 bg-white p-4 rounded-2xl shadow'><WorldMap iocs={iocs} /></div>
        <div className='col-span-1 lg:col-span-2'><ReportPanel token={token} /></div>
      </div>
    </div>
  );
}

export default App;
