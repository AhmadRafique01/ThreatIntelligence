import React, { useState } from 'react';
import axios from 'axios';

const ReportPanel: React.FC<{token:string}> = ({ token }) => {
  const [loading, setLoading] = useState(false);
  const [summary, setSummary] = useState('');

  const fetchReport = async () => {
    setLoading(true);
    try {
      const res = await axios.get('http://localhost:8000/report?limit=20', { headers: { Authorization: `Bearer ${token}` } });
      setSummary(res.data.summary);
    } catch (err) {
      setSummary('Failed to fetch report.');
    } finally { setLoading(false); }
  };

  const downloadPdf = () => {
    const url = 'http://localhost:8000/report/pdf?limit=20';
    const link = document.createElement('a'); link.href = url; link.download = 'threat_report.pdf'; document.body.appendChild(link); link.click(); document.body.removeChild(link);
  };

  return (
    <div className='bg-white p-4 rounded-2xl shadow'>
      <div className='flex justify-between items-center mb-2'>
        <h2 className='text-xl font-semibold'>Threat Report</h2>
        <div className='space-x-2'>
          <button onClick={fetchReport} className='px-3 py-1 bg-indigo-600 text-white rounded-lg'>{loading? 'Loading...':'Generate'}</button>
          <button onClick={downloadPdf} className='px-3 py-1 bg-green-600 text-white rounded-lg'>Download PDF</button>
        </div>
      </div>
      <div className='whitespace-pre-wrap text-sm bg-gray-50 p-2 rounded'>{summary || 'Click Generate to view summary'}</div>
    </div>
  );
};

export default ReportPanel;
