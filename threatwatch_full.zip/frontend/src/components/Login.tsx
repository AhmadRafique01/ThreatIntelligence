import React, { useState } from 'react';
import axios from 'axios';

const Login: React.FC<{onLogin:(t:string)=>void}> = ({ onLogin }) => {
  const [username,setUsername]=useState('');
  const [password,setPassword]=useState('');
  const [error,setError]=useState('');

  const handleSubmit = async (e:React.FormEvent) => {
    e.preventDefault(); setError('');
    try {
      const form = new URLSearchParams(); form.append('username', username); form.append('password', password);
      const res = await axios.post('http://localhost:8000/auth/login', form, { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } });
      onLogin(res.data.access_token);
    } catch (err) { setError('Login failed'); }
  };

  return (
    <div className='flex items-center justify-center h-screen bg-gray-100'>
      <form onSubmit={handleSubmit} className='bg-white p-6 rounded-xl shadow w-80 space-y-4'>
        <h2 className='text-xl font-semibold'>Login</h2>
        {error && <div className='text-red-500 text-sm'>{error}</div>}
        <input className='border px-2 py-1 w-full rounded' placeholder='Username' value={username} onChange={(e)=>setUsername(e.target.value)} />
        <input className='border px-2 py-1 w-full rounded' type='password' placeholder='Password' value={password} onChange={(e)=>setPassword(e.target.value)} />
        <button type='submit' className='w-full py-1 bg-blue-600 text-white rounded hover:bg-blue-700'>Login</button>
      </form>
    </div>
  );
};

export default Login;
