import React from 'react';
import { ComposableMap, Geographies, Geography, Marker } from 'react-simple-maps';

const geoUrl = 'https://raw.githubusercontent.com/deldersveld/topojson/master/world-countries.json';

const WorldMap: React.FC<{iocs:any[]}> = ({ iocs }) => {
  const markers = (iocs || []).filter(i=>i.geo && i.geo.lat && i.geo.lon).map((ioc:any, idx:number)=>({ name:ioc.value, coordinates:[ioc.geo.lon, ioc.geo.lat]}));
  return (
    <ComposableMap projectionConfig={{scale:120}}>
      <Geographies geography={geoUrl}>{({geographies})=>geographies.map(geo=>(<Geography key={geo.rsmKey} geography={geo} fill='#E5E7EB' stroke='#D1D5DB'/>))}</Geographies>
      {markers.map((m:any,i:number)=>(<Marker key={i} coordinates={m.coordinates}><circle r={3} fill='#EF4444' /></Marker>))}
    </ComposableMap>
  );
};

export default WorldMap;
