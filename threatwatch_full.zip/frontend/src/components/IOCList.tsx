import React, { useState } from 'react';

type Props = { iocs: any[] };

const IOCList: React.FC<Props> = ({ iocs }) => {
  const [search, setSearch] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [minSeverity, setMinSeverity] = useState(0);

  const handleDownload = (format: 'csv'|'pdf') => {
    const url = `http://localhost:8000/export/iocs.${format}`;
    const link = document.createElement('a');
    link.href = url;
    link.download = `iocs.${format}`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const filtered = iocs.filter((ioc) => {
    const matchSearch =
      (ioc.value || '').toLowerCase().includes(search.toLowerCase()) ||
      (ioc.ioc_type || '').toLowerCase().includes(search.toLowerCase());
    const matchType = filterType === 'all' || (ioc.ioc_type === filterType);
    const matchSeverity = (ioc.severity || 0) >= minSeverity;
    return matchSearch && matchType && matchSeverity;
  });

  return (
    <div>
      <div className='flex flex-col md:flex-row justify-between mb-3 space-y-2 md:space-y-0'>
        <div className='flex space-x-2'>
          <input value={search} onChange={(e)=>setSearch(e.target.value)} placeholder='Search...' className='border px-2 py-1 rounded' />
          <select value={filterType} onChange={(e)=>setFilterType(e.target.value)} className='border px-2 py-1 rounded'>
            <option value='all'>All Types</option>
            <option value='ip'>IP</option>
            <option value='url'>URL</option>
            <option value='domain'>Domain</option>
            <option value='hash'>Hash</option>
            <option value='email'>Email</option>
          </select>
          <input type='number' min={0} max={10} value={minSeverity} onChange={(e)=>setMinSeverity(Number(e.target.value))} className='w-20 border px-2 py-1 rounded' placeholder='Severity ≥' />
        </div>
        <div className='space-x-2'>
          <button onClick={()=>handleDownload('csv')} className='px-3 py-1 bg-blue-600 text-white rounded-lg'>Export CSV</button>
          <button onClick={()=>handleDownload('pdf')} className='px-3 py-1 bg-green-600 text-white rounded-lg'>Export PDF</button>
        </div>
      </div>

      <div className='overflow-y-auto max-h-96'>
        <table className='w-full text-sm border'>
          <thead className='bg-gray-200'>
            <tr><th className='p-2 border'>Type</th><th className='p-2 border'>Value</th><th className='p-2 border'>Severity</th><th className='p-2 border'>Country</th></tr>
          </thead>
          <tbody>
            {filtered.map((ioc:any)=>(
              <tr key={ioc.id}><td className='border p-1'>{ioc.ioc_type}</td><td className='border p-1 truncate max-w-[200px]'>{ioc.value}</td><td className='border p-1 font-bold'>{ioc.severity}</td><td className='border p-1'>{ioc.geo?.country || '-'}</td></tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default IOCList;
