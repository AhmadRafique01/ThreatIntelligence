import React from 'react';
import { LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, ResponsiveContainer } from 'recharts';

const ForecastChart: React.FC<{forecast:any[]}> = ({ forecast }) => {
  return (
    <ResponsiveContainer width='100%' height={300}>
      <LineChart data={forecast}>
        <CartesianGrid strokeDasharray='3 3' />
        <XAxis dataKey='ds' />
        <YAxis />
        <Tooltip />
        <Line type='monotone' dataKey='yhat' stroke='#2563eb' />
      </LineChart>
    </ResponsiveContainer>
  );
};

export default ForecastChart;
