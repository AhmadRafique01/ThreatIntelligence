# Threatwatch Full Project (Starter)

This archive contains a complete starter implementation for the Threatwatch project:
- backend/ : FastAPI backend
- frontend/: React + Tailwind dashboard

See backend/requirements.txt and frontend/package.json for dependencies.
Follow the README in each folder to run services locally.
