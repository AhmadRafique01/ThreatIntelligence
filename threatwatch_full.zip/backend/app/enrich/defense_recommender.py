from typing import Dict, Any, List
def recommend_defense(ioc: Dict[str, Any]) -> List[str]:
    recs = []
    t = (ioc.get('ioc_type') or '').lower()
    severity = ioc.get('severity', 0)
    mitre = [m.get('technique_id') for m in (ioc.get('mitre') or [])]
    if t == 'ip':
        recs.append('Block IP in firewall / perimeter devices')
        recs.append('Add to SIEM correlation rules')
    elif t in ['url','domain','hostname']:
        recs.append('Add to DNS sinkhole / proxy blocklist')
        recs.append('Monitor outbound traffic for matches')
    elif 'hash' in t:
        recs.append('Scan endpoints for file with given hash (AV, YARA)')
        recs.append('Block hash in EDR solution')
    elif t == 'email':
        recs.append('Update mail filter / spam rules')
        recs.append('Conduct phishing awareness training')
    if severity >= 8:
        recs.append('Escalate to incident response team')
    elif severity <= 3:
        recs.append('Log only, monitor for recurrence')
    if 'T1566' in mitre:
        recs.append('Tighten email filters for phishing attempts')
        recs.append('Run targeted phishing awareness campaign')
    if 'T1071' in mitre:
        recs.append('Inspect network egress traffic for C2 patterns')
        recs.append('Deploy IDS rules for common C2 channels')
    recs = list(dict.fromkeys(recs))
    return recs
