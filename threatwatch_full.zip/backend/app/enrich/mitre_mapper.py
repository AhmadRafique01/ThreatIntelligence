import json, os, logging
from typing import List, Dict
from ..config import settings

logger = logging.getLogger(__name__)
_mapping = None
def load_mapping():
    global _mapping
    if _mapping is None:
        path = settings.MITRE_MAPPING_FILE
        if not os.path.exists(path):
            _mapping = {}
        else:
            with open(path,'r') as f:
                _mapping = json.load(f)
    return _mapping

def map_tags_to_mitre(tags: List[str]) -> List[Dict]:
    mapping = load_mapping()
    results = []
    for tag in tags or []:
        key = tag.lower()
        for rule, tech in mapping.items():
            if rule in key:
                results.append(tech)
    return results
