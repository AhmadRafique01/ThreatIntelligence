from datetime import datetime
from typing import Dict, Any, Optional

BASE_WEIGHTS = {
    'ip': 4.0,
    'url': 6.0,
    'domain': 5.0,
    'hash': 7.0,
    'email': 3.0,
}

def compute_score(ioc: Dict[str, Any]) -> float:
    t = (ioc.get('ioc_type') or 'unknown').lower()
    score = BASE_WEIGHTS.get(t, 4.0)
    last_seen = ioc.get('last_seen')
    try:
        if last_seen:
            from dateutil import parser as dp
            if isinstance(last_seen, str):
                last_seen = dp.parse(last_seen)
            days_old = (datetime.utcnow() - last_seen).days
            if days_old < 1:
                score += 2.0
            elif days_old < 7:
                score += 1.0
    except Exception:
        pass
    mitre = ioc.get('mitre') or []
    if mitre:
        score += 1.0
    return max(1.0, min(10.0, score))
