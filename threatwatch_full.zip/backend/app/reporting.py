import os, io
from .crud import list_iocs
from .utils.exporter import export_pdf
OPENAI_API_KEY = os.getenv('OPENAI_API_KEY','')
try:
    import openai
    if OPENAI_API_KEY:
        openai.api_key = OPENAI_API_KEY
except Exception:
    openai = None

async def generate_summary(limit: int = 20) -> str:
    iocs = await list_iocs(limit=limit)
    if not iocs:
        return 'No indicators found in the given timeframe.'
    if openai and OPENAI_API_KEY:
        context = '\n'.join(f"- [{i['ioc_type']}] {i['value']} (Severity {i['severity']})" for i in iocs[:15])
        prompt = f"""You are a cyber threat intelligence analyst. Summarize the following indicators into a professional threat report. Highlight observed patterns, mapped MITRE ATT&CK techniques, and defense recommendations.\nIndicators:\n{context}"""
        try:
            resp = openai.ChatCompletion.create(model='gpt-4o-mini', messages=[{'role':'system','content':'You are a CTI analyst.'},{'role':'user','content':prompt}], max_tokens=400)
            return resp['choices'][0]['message']['content']
        except Exception as e:
            return f'LLM generation failed: {e}'
    text = 'Threatwatch Intelligence Report\n\n'
    text += f'Total IOCs analyzed: {len(iocs)}\n\nTop 5 indicators:\n'
    for i in iocs[:5]:
        text += f"- [{i['ioc_type']}] {i['value']} (Severity {i['severity']})\n"
    return text

async def generate_report_pdf(limit: int = 20) -> bytes:
    iocs = await list_iocs(limit=limit)
    summary = await generate_summary(limit=limit)
    return export_pdf(iocs, title=summary.splitlines()[0])
