from datetime import datetime, timedelta
from typing import Optional
from fastapi import Depends, HTTPException, status, APIRouter
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from jose import JWTError, jwt
from passlib.context import CryptContext
from .database import database, metadata, engine
from .models import users
from sqlalchemy import insert, select

SECRET_KEY = 'supersecret-change-me'
ALGORITHM = 'HS256'
ACCESS_TOKEN_EXPIRE_MINUTES = 120

pwd_context = CryptContext(schemes=['bcrypt'], deprecated='auto')
oauth2_scheme = OAuth2PasswordBearer(tokenUrl='auth/login')

router = APIRouter(prefix='/auth', tags=['auth'])

def verify_password(plain, hashed):
    return pwd_context.verify(plain, hashed)

def get_password_hash(password):
    return pwd_context.hash(password)

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=15))
    to_encode.update({'exp': expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

async def get_current_user(token: str = Depends(oauth2_scheme)):
    cred_exc = HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail='Could not validate credentials', headers={'WWW-Authenticate': 'Bearer'})
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get('sub')
        if username is None:
            raise cred_exc
    except JWTError:
        raise cred_exc
    query = select(users).where(users.c.username == username)
    user = await database.fetch_one(query)
    if user is None:
        raise cred_exc
    return user

@router.post('/register')
async def register(username: str, password: str):
    hashed = get_password_hash(password)
    try:
        q = insert(users).values(username=username, password_hash=hashed, role='user')
        await database.execute(q)
    except Exception as e:
        raise HTTPException(status_code=400, detail='User may already exist')
    return {'msg':'User created'}

@router.post('/login')
async def login(form_data: OAuth2PasswordRequestForm = Depends()):
    q = select(users).where(users.c.username == form_data.username)
    user = await database.fetch_one(q)
    if not user or not verify_password(form_data.password, user['password_hash']):
        raise HTTPException(status_code=401, detail='Invalid credentials')
    access_token = create_access_token(data={'sub': user['username']}, expires_delta=timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))
    return {'access_token': access_token, 'token_type': 'bearer'}
