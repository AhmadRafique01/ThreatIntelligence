import csv, io
from typing import List, Dict
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet

def export_csv(iocs: List[Dict]) -> bytes:
    output = io.StringIO()
    if not iocs:
        return b''
    fieldnames = list(iocs[0].keys())
    writer = csv.DictWriter(output, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(iocs)
    return output.getvalue().encode('utf-8')

def export_pdf(iocs: List[Dict], title: str = 'IOC Report') -> bytes:
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    styles = getSampleStyleSheet()
    elements = []
    elements.append(Paragraph(title, styles['Title']))
    if iocs:
        headers = ['ioc_type','value','severity','country','defense']
        table_data = [headers]
        for ioc in iocs:
            geo = ioc.get('geo') or {}
            row = [
                ioc.get('ioc_type',''),
                str(ioc.get('value','')),
                str(ioc.get('severity','')),
                geo.get('country',''),
                ', '.join(ioc.get('defense') or [])
            ]
            table_data.append(row)
        table = Table(table_data, repeatRows=1)
        table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.gray),
                                  ('TEXTCOLOR',(0,0),(-1,0),colors.whitesmoke),
                                  ('ALIGN',(0,0),(-1,-1),'LEFT'),
                                  ('FONTNAME',(0,0),(-1,0),'Helvetica-Bold'),
                                  ('BOTTOMPADDING',(0,0),(-1,0),6),
                                  ('GRID',(0,0),(-1,-1),0.5,colors.black)]))
        elements.append(table)
    doc.build(elements)
    pdf = buffer.getvalue()
    buffer.close()
    return pdf
