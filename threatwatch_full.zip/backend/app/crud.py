from sqlalchemy import select, and_, func
from .database import database
from .models import iocs
from datetime import datetime

async def create_ioc(ioc: dict):
    query = select(iocs).where(and_(iocs.c.value == ioc['value'], iocs.c.ioc_type == ioc['ioc_type']))
    existing = await database.fetch_one(query)
    if existing:
        update_values = {}
        if ioc.get('last_seen'):
            update_values['last_seen'] = ioc['last_seen']
        if ioc.get('source'):
            update_values['source'] = ioc['source']
        if update_values:
            update_values['updated_at'] = datetime.utcnow()
            upd = iocs.update().where(iocs.c.id == existing['id']).values(**update_values)
            await database.execute(upd)
        return dict(existing)
    else:
        ins = iocs.insert().values(**ioc)
        pk = await database.execute(ins)
        rec = await database.fetch_one(select(iocs).where(iocs.c.id == pk))
        return dict(rec)

async def list_iocs(limit: int = 100, offset: int = 0, filters: dict = None):
    q = select(iocs).limit(limit).offset(offset).order_by(iocs.c.created_at.desc())
    if filters:
        if filters.get('ioc_type'):
            q = q.where(iocs.c.ioc_type == filters['ioc_type'])
        if filters.get('value'):
            q = q.where(iocs.c.value.ilike(f"%{filters['value']}%"))
        if filters.get('min_severity'):
            q = q.where(iocs.c.severity >= float(filters['min_severity']))
    rows = await database.fetch_all(q)
    return [dict(r) for r in rows]

async def count_iocs_grouped_by_date():
    q = select(func.date_trunc('day', iocs.c.created_at).label('day'), func.count().label('count')).group_by('day').order_by('day')
    rows = await database.fetch_all(q)
    return [{'date': str(r['day'].date()), 'count': r['count']} for r in rows]
