import httpx, time, logging
from datetime import datetime
from typing import List, Dict, Optional
from ..crud import create_ioc

logger = logging.getLogger(__name__)
URLHAUS_JSON_RECENT = "https://urlhaus-api.abuse.ch/v1/urls/recent/"
URLHAUS_PLAINTEXT_RECENT = "https://urlhaus.abuse.ch/downloads/urls/recent/"
MIN_FETCH_SECONDS = 5*60
_last_fetch_time = 0.0

def iso_to_dt(s):
    if not s: return None
    try:
        return datetime.fromisoformat(s.replace('Z', '+00:00'))
    except Exception:
        return None

def guess_type(value: str):
    if not value: return "unknown"
    if value.count('.') == 3 and all(p.isdigit() for p in value.split('.')):
        return 'ip'
    if value.startswith('http'):
        return 'url'
    if '.' in value:
        return 'domain'
    return 'unknown'

async def fetch_urlhaus_recent_json(client: httpx.AsyncClient, timeout: int = 20):
    try:
        r = await client.get(URLHAUS_JSON_RECENT, timeout=timeout)
        if r.status_code != 200:
            return None
        data = r.json()
        if isinstance(data, dict) and 'data' in data:
            return data['data']
        if isinstance(data, list):
            return data
        return None
    except Exception:
        return None

async def fetch_urlhaus_plaintext(client: httpx.AsyncClient, url: str, timeout: int = 30):
    try:
        r = await client.get(url, timeout=timeout)
        if r.status_code != 200:
            return None
        lines = [line.strip() for line in r.text.splitlines() if line.strip() and not line.startswith('#')]
        return lines
    except Exception:
        return None

def normalize_json_item(item: Dict):
    url = item.get('url') or item.get('urlhaus_url') or item.get('value')
    date_added = item.get('date_added') or item.get('first_seen') or item.get('added_on') or None
    first_seen = None
    if date_added:
        try:
            first_seen = datetime.fromisoformat(date_added.replace('Z', '+00:00'))
        except Exception:
            first_seen = None
    severity = item.get('severity') or 5.0
    normalized = {
        'ioc_type': 'url',
        'value': url,
        'source': 'urlhaus',
        'first_seen': first_seen,
        'last_seen': first_seen,
        'raw_payload': item,
        'severity': float(severity),
        'tags': item.get('tags') or [],
    }
    return normalized

async def parse_and_store_urlhaus_items(items: List[Dict]):
    count=0
    for it in items:
        norm = normalize_json_item(it)
        if not norm['value']: continue
        await create_ioc(norm)
        count+=1
    logger.info('URLhaus parser: stored %d items', count)
    return count

async def parse_and_store_plaintext_urls(lines: List[str]):
    count=0
    for url in lines:
        norm={
            'ioc_type':'url',
            'value':url,
            'source':'urlhaus_plaintext',
            'first_seen':None,
            'last_seen':None,
            'raw_payload':{'source_line':url},
            'severity':5.0,
            'tags':[],
        }
        await create_ioc(norm)
        count+=1
    logger.info('URLhaus plaintext parser: stored %d URLs', count)
    return count

async def fetch_and_ingest_urlhaus(max_items: int = 1000):
    global _last_fetch_time
    now = time.time()
    if now - _last_fetch_time < MIN_FETCH_SECONDS:
        return {'status':'skipped_rate_limit'}
    async with httpx.AsyncClient() as client:
        data = await fetch_urlhaus_recent_json(client)
        if data:
            items = data[:max_items]
            stored = await parse_and_store_urlhaus_items(items)
            _last_fetch_time = time.time()
            return {'status':'ok','endpoint':'json_recent','stored':stored}
        lines = await fetch_urlhaus_plaintext(client, URLHAUS_PLAINTEXT_RECENT)
        if lines:
            lines = lines[:max_items]
            stored = await parse_and_store_plaintext_urls(lines)
            _last_fetch_time = time.time()
            return {'status':'ok','endpoint':'plaintext_recent','stored':stored}
    raise Exception('Unable to fetch URLhaus')
