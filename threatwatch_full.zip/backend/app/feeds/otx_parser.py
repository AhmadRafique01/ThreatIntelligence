import os, httpx, logging
from dateutil import parser as dateparser
from typing import List, Dict, Any
from ..crud import create_ioc

logger = logging.getLogger(__name__)
OTX_API_BASE = "https://otx.alienvault.com/api/v1"
OTX_API_KEY = os.getenv('OTX_API_KEY', '')
HEADERS = {'X-OTX-API-KEY': OTX_API_KEY} if OTX_API_KEY else {}

def normalize_indicator(ind: Dict[str, Any], pulse_name: str = None) -> Dict:
    ind_type = ind.get('type') or 'unknown'
    val = ind.get('indicator') or ind.get('indicator', None)
    sev_map = {'IPv4':6.0, 'domain':5.0, 'hostname':5.0, 'URL':7.0, 'FileHash-SHA256':8.0}
    severity = sev_map.get(ind_type, 5.0)
    first_seen = None
    if ind.get('created'):
        try:
            first_seen = dateparser.parse(ind['created'])
        except Exception:
            pass
    tags = []
    if pulse_name:
        tags.append(pulse_name)
    norm = {
        'ioc_type': ind_type.lower(),
        'value': val,
        'source': 'otx',
        'first_seen': first_seen,
        'last_seen': first_seen,
        'raw_payload': ind,
        'severity': severity,
        'tags': tags,
    }
    return norm

async def fetch_recent_pulses(limit: int = 5) -> List[Dict]:
    url = f"{OTX_API_BASE}/pulses/subscribed"
    async with httpx.AsyncClient() as client:
        try:
            r = await client.get(url, headers=HEADERS, timeout=30)
            if r.status_code != 200:
                logger.warning('OTX pulses request failed %s', r.status_code)
                return []
            data = r.json()
            return data.get('results', [])[:limit]
        except Exception as e:
            logger.error('OTX fetch error %s', e)
            return []

async def fetch_and_ingest_otx(limit_pulses: int = 5, limit_iocs: int = 500):
    pulses = await fetch_recent_pulses(limit=limit_pulses)
    stored = 0
    for pulse in pulses:
        pulse_name = pulse.get('name')
        indicators = pulse.get('indicators', [])
        for ind in indicators[:limit_iocs]:
            norm = normalize_indicator(ind, pulse_name)
            if norm.get('value'):
                await create_ioc(norm)
                stored += 1
    return {'status':'ok','stored':stored,'pulses':len(pulses)}
