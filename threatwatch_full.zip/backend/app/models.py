from sqlalchemy import Table, Column, Integer, String, DateTime, JSON, Float, Boolean, text, func
from .database import metadata

iocs = Table(
    "iocs",
    metadata,
    Column("id", Integer, primary_key=True),
    Column("ioc_type", String(32), nullable=False),
    Column("value", String(1024), nullable=False, index=True),
    Column("source", String(256)),
    Column("first_seen", DateTime),
    Column("last_seen", DateTime),
    Column("raw_payload", JSON),
    Column("severity", Float, server_default="0"),
    Column("tags", JSON, server_default="[]"),
    Column("geo", JSON, nullable=True),
    Column("mitre", JSON, nullable=True),
    Column("apt_attribution", JSON, nullable=True),
    Column("defense", JSON, server_default="[]"),
    Column("created_at", DateTime, server_default=func.now()),
    Column("updated_at", DateTime, server_default=func.now(), onupdate=func.now()),
    Column("active", Boolean, server_default="true")
)

# simple users table for auth
from sqlalchemy import MetaData
users = Table(
    "users",
    metadata,
    Column('username', String(128), primary_key=True),
    Column('password_hash', String(256), nullable=False),
    Column('role', String(32), nullable=False, server_default='user'),
)
