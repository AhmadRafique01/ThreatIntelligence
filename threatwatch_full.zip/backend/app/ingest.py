import asyncio
import logging
from .feeds import urlhaus_parser, otx_parser
from .crud import create_ioc

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

async def fetch_sample_feed():
    data = [
        {"ioc_type": "ip", "value": "203.0.113.1", "source": "sample", "first_seen": "2025-09-01T00:00:00Z", "last_seen": "2025-09-10T12:00:00Z", "raw_payload": {"note":"simulated"}, "severity": 7.0},
        {"ioc_type": "url", "value": "http://malicious.example/bad", "source": "sample", "first_seen": "2025-09-09T13:00:00Z", "last_seen": "2025-09-09T13:00:00Z", "raw_payload": {"html":"<a>phish</a>"}, "severity": 6.5},
    ]
    for item in data:
        norm = {
            'ioc_type': item.get('ioc_type'),
            'value': item.get('value'),
            'source': item.get('source'),
            'first_seen': item.get('first_seen'),
            'last_seen': item.get('last_seen'),
            'raw_payload': item.get('raw_payload', {}),
            'severity': float(item.get('severity') or 1.0),
            'tags': item.get('tags', []),
        }
        await create_ioc(norm)

async def run_once():
    try:
        res = await urlhaus_parser.fetch_and_ingest_urlhaus(max_items=200)
        logger.info("URLhaus ingestion result: %s", res)
    except Exception as e:
        logger.exception("URLhaus ingestion failed: %s", e)
    try:
        res = await otx_parser.fetch_and_ingest_otx(limit_pulses=3, limit_iocs=100)
        logger.info("OTX ingestion result: %s", res)
    except Exception as e:
        logger.exception("OTX ingestion failed: %s", e)
    # ensure DB not empty for demo
    await fetch_sample_feed()

if __name__ == '__main__':
    asyncio.run(run_once())
