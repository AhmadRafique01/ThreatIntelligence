import io, logging
from fastapi import FastAPI, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from .database import database, engine, metadata
from . import models, crud, ingest, reporting
from .auth import router as auth_router, get_current_user
from .utils.exporter import export_csv, export_pdf
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from .crud import list_iocs, count_iocs_grouped_by_date
from .enrich.scoring import compute_score

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title='Threatwatch - API')
metadata.create_all(engine)

scheduler = AsyncIOScheduler()

@app.on_event('startup')
async def startup():
    await database.connect()
    # schedule ingestion every 10 minutes
    scheduler.add_job(ingest.run_once, 'interval', minutes=10, id='ingest_job', replace_existing=True)
    scheduler.start()
    logger.info('Scheduler started')

@app.on_event('shutdown')
async def shutdown():
    await database.disconnect()
    scheduler.shutdown()

app.include_router(auth_router)

@app.get('/')
async def root():
    return {'message':'Threatwatch API running'}

@app.post('/ingest/run')
async def run_ingest(user=Depends(get_current_user)):
    await ingest.run_once()
    return {'status':'ok'}

@app.get('/iocs')
async def get_iocs(limit: int = Query(100, le=1000), offset: int = 0, ioc_type: str = None, min_severity: float = None, user=Depends(get_current_user)):
    filters = {}
    if ioc_type:
        filters['ioc_type'] = ioc_type
    if min_severity is not None:
        filters['min_severity'] = min_severity
    rows = await crud.list_iocs(limit=limit, offset=offset, filters=filters)
    return {'count': len(rows), 'results': rows}

@app.get('/iocs/counts')
async def ioc_counts(user=Depends(get_current_user)):
    data = await count_iocs_grouped_by_date()
    return {'counts': data}

@app.get('/forecast')
async def forecast(days: int = Query(14, ge=1, le=90), user=Depends(get_current_user)):
    from . import forecasting
    f = await forecasting.compute_forecast(days)
    return f

@app.get('/export/iocs.csv')
async def export_iocs_csv(limit: int = 100, user=Depends(get_current_user)):
    rows = await list_iocs(limit=limit)
    if not rows:
        raise HTTPException(status_code=404, detail='No IOCs found')
    csv_bytes = export_csv(rows)
    return StreamingResponse(io.BytesIO(csv_bytes), media_type='text/csv', headers={'Content-Disposition':'attachment; filename=iocs.csv'})

@app.get('/export/iocs.pdf')
async def export_iocs_pdf(limit: int = 100, user=Depends(get_current_user)):
    rows = await list_iocs(limit=limit)
    if not rows:
        raise HTTPException(status_code=404, detail='No IOCs found')
    pdf_bytes = export_pdf(rows, title='Threatwatch IOC Report')
    return StreamingResponse(io.BytesIO(pdf_bytes), media_type='application/pdf', headers={'Content-Disposition':'attachment; filename=iocs.pdf'})

@app.get('/report')
async def get_report(limit: int = 20, user=Depends(get_current_user)):
    text = await reporting.generate_summary(limit=limit)
    return {'summary': text}

@app.get('/report/pdf')
async def get_report_pdf(limit: int = 20, user=Depends(get_current_user)):
    pdf = await reporting.generate_report_pdf(limit=limit)
    return StreamingResponse(io.BytesIO(pdf), media_type='application/pdf', headers={'Content-Disposition':'attachment; filename=threat_report.pdf'})
