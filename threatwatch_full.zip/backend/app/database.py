from databases import Database
from sqlalchemy import MetaData, create_engine
from .config import settings

database = Database(settings.DATABASE_URL)
metadata = MetaData()
# synchronous engine for create_all
engine = create_engine(settings.DATABASE_URL.replace("+asyncpg", ""), future=True)
