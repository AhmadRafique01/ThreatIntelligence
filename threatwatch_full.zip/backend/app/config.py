import os
from pydantic import BaseSettings

class Settings(BaseSettings):
    DATABASE_URL: str = os.getenv("DATABASE_URL", "postgresql+asyncpg://threatwatch:threatwatch@localhost:5432/threatwatch")
    SAMPLE_FEED_URL: str = os.getenv("SAMPLE_FEED_URL", "")
    GEOIP_DB_PATH: str = os.getenv("GEOIP_DB_PATH", "data/GeoLite2-City.mmdb")
    MITRE_MAPPING_FILE: str = os.getenv("MITRE_MAPPING_FILE", "data/mitre_mapping.json")
    OPENAI_API_KEY: str = os.getenv("OPENAI_API_KEY", "")

settings = Settings()
